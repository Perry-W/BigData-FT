from django.apps import AppConfig


class BkManageConfig(AppConfig):
    name = 'bk_manage'
